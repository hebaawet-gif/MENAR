import 'package:flutter/material.dart';
import 'core/router/app_router.dart';
import 'core/theme/menar_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MenarApp());
}

class MenarApp extends StatelessWidget {
  const MenarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'MENAR',
      debugShowCheckedModeBanner: false,
      theme: MenarTheme.light,
      routerConfig: appRouter,
    );
  }
}
