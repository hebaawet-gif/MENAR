import 'package:flutter/material.dart';

class QuranPage extends StatelessWidget {
  const QuranPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Qur’an')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Card(child: ListTile(leading: Icon(Icons.bookmark_outline), title: Text('Last reading'), subtitle: Text('Qur’an reader data will connect here.'))),
          SizedBox(height: 10),
          Card(child: ListTile(title: Text('Surah Al-Fatihah'), subtitle: Text('1 • Al-Fatihah • 7 Ayat'), trailing: Icon(Icons.chevron_right))),
          Card(child: ListTile(title: Text('Surah Al-Baqarah'), subtitle: Text('2 • Al-Baqarah • 286 Ayat'), trailing: Icon(Icons.chevron_right))),
          Card(child: ListTile(title: Text('Surah Aal-E-Imran'), subtitle: Text('3 • Aal-E-Imran • 200 Ayat'), trailing: Icon(Icons.chevron_right))),
        ],
      ),
    );
  }
}
