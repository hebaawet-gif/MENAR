import 'package:flutter/material.dart';

class AdhkarPage extends StatelessWidget {
  const AdhkarPage({super.key});

  @override
  Widget build(BuildContext context) {
    const items = [
      ('SubhanAllah', 'Glory be to Allah'),
      ('Alhamdulillah', 'All praise belongs to Allah'),
      ('Allahu Akbar', 'Allah is the Greatest'),
      ('Astaghfirullah', 'I seek forgiveness from Allah'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Daily Adhkar')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        itemBuilder: (_, i) => Card(
          child: ListTile(
            leading: CircleAvatar(child: Text('${i + 1}')),
            title: Text(items[i].$1, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(items[i].$2),
            trailing: const Icon(Icons.favorite_outline),
          ),
        ),
      ),
    );
  }
}
