import 'package:flutter/material.dart';

class PrayerPage extends StatelessWidget {
  const PrayerPage({super.key});

  @override
  Widget build(BuildContext context) {
    const prayers = [
      ('Fajr', '05:10'),
      ('Dhuhr', '12:45'),
      ('Asr', '16:05'),
      ('Maghrib', '18:35'),
      ('Isha', '19:50'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Prayer Times')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Today', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: 5),
                  Text('Addis Ababa • Prayer API integration pending'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          ...prayers.map((p) => Card(
            child: ListTile(
              leading: const Icon(Icons.access_time),
              title: Text(p.$1),
              trailing: Text(p.$2, style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
          )),
        ],
      ),
    );
  }
}
