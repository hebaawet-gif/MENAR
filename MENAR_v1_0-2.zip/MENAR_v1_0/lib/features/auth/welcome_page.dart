import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/menar_theme.dart';

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.mosque_rounded, size: 90, color: MenarTheme.green),
              const SizedBox(height: 20),
              const Text(
                'MENAR',
                style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold, color: MenarTheme.darkGreen),
              ),
              const SizedBox(height: 8),
              const Text(
                'Your Islamic companion',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 17),
              ),
              const SizedBox(height: 42),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () => context.go('/login'),
                  child: const Text('Sign in'),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => context.go('/register'),
                  child: const Text('Create account'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
