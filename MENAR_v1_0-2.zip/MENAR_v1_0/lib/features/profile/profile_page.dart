import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/services/session_service.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final _session = SessionService();
  String name = 'Guest';
  String email = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final n = await _session.getName();
    final e = await _session.getEmail();
    if (mounted) setState(() { name = n; email = e; });
  }

  Future<void> _logout() async {
    await _session.signOut();
    if (!mounted) return;
    context.go('/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile & Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text(name),
              subtitle: Text(email),
            ),
          ),
          const SizedBox(height: 12),
          const Card(child: ListTile(leading: Icon(Icons.language), title: Text('Language'), subtitle: Text('English'))),
          const Card(child: ListTile(leading: Icon(Icons.notifications_outlined), title: Text('Notifications'))),
          const Card(child: ListTile(leading: Icon(Icons.bookmark_outline), title: Text('Bookmarks'))),
          const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('About MENAR'), subtitle: Text('MENAR v1.0'))),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _logout,
            icon: const Icon(Icons.logout),
            label: const Text('Sign out'),
          ),
        ],
      ),
    );
  }
}
