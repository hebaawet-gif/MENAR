import 'package:flutter/material.dart';

class QiblahPage extends StatelessWidget {
  const QiblahPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Qiblah')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Icon(Icons.explore, size: 100),
              SizedBox(height: 20),
              Text('Qiblah compass', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              Text('Compass and location sensor integration will be connected in the device-ready implementation.'),
            ],
          ),
        ),
      ),
    );
  }
}
